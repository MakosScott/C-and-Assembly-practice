/*----------------
File: Thermistor.h
Description: Header file for Thermistor Module
--------------------*/

// Function Prototypes
void initThermistor(void);
int getTemp(void);
