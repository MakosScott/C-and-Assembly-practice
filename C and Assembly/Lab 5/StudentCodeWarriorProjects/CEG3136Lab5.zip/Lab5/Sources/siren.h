/*----------------
File: siren.h
Description: Header file for Siren Module
------------------*/

void initSiren(void);
void turnOnSiren(void);
void turnOffSiren(void);



