/*------------------------------------------------
 * File: armed.h
 * Description: Include file with definitions for 
 *              the Armed Module
--------------------------------------------------*/

// Prototypes - Entry Points
void enableAlarm(void);
void triggerAlarm(void);

